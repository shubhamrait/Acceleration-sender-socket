package com.example.shubahm.myapplication;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStreamWriter;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import android.os.Handler;
import static android.hardware.Sensor.TYPE_GYROSCOPE;

public class MainActivity extends AppCompatActivity
{
    class Accelerometer
    {
        public float ax=0;
        public float ay=0;
        public float az=0;
        Accelerometer()
        {
            this.ax=0;
            this.ay=0;
            this.az=0;
        }
    }
    public static String a="";
    private SensorManager mSensorManager;
    private Sensor mAccelerometer;
    private Sensor mGyroscope;
    public TextView txt,txt2,txt3;
    public static final int SERVERPORT = 6000;
    private ServerSocket serverSocket;
    Accelerometer acc=new Accelerometer();
    public Button button, button2;
    private Button exit;
    public static boolean clicked=false;
    public static int state = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txt=(TextView)findViewById(R.id.text1);
        txt2=(TextView)findViewById(R.id.text2);
        txt3 = (TextView)findViewById(R.id.text3);
        txt3.setText("State: "+MainActivity.state+" Not Pressed ");
        button = findViewById(R.id.button1);
        button.setBackgroundResource(R.drawable.startbuttonup);
        button.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    button.setBackgroundResource(R.drawable.startbuttondown);
                    if((MainActivity.state<2))
                    {
                        MainActivity.state = 1;
                    }
                    txt3.setText("State: "+MainActivity.state+"     Pressed ");
                } else if (event.getAction() == MotionEvent.ACTION_UP)
                {
                    button.setBackgroundResource(R.drawable.startbuttonup);
                    MainActivity.state=2;
                    txt3.setText("State: "+MainActivity.state+" Not Pressed ");
                }
                return true;
            }
        });
        button2 = findViewById(R.id.button2);

        button2.setOnTouchListener(new View.OnTouchListener()
        {
            @Override
            public boolean onTouch(View v, MotionEvent event)
            {
                if(event.getAction() == MotionEvent.ACTION_DOWN)
                {
                    button2.setBackgroundResource((R.drawable.buttonshapepressed));
                    if(MainActivity.state!=0)
                    {
                        MainActivity.state=0;
                        txt3.setText("State: "+MainActivity.state+" Not Pressed ");
                    }
                } else if (event.getAction() == MotionEvent.ACTION_UP)
                {
                    button2.setBackgroundResource((R.drawable.buttonshape));
                }
                return true;
            }
        });
        exit = findViewById(R.id.button);
        exit.setBackgroundResource(R.drawable.buttonshape);
        exit.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                exit.setBackgroundResource(R.drawable.buttonshapepressed);
                System.exit(0);
            }
        });




        Configure.main=this;
        mSensorManager = (SensorManager)getSystemService(SENSOR_SERVICE);
        mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION);
        mGyroscope = mSensorManager.getDefaultSensor(TYPE_GYROSCOPE);
        ServerThread srv=new ServerThread();
        Thread t1=new Thread(srv);
        t1.start();
    }
    protected void onResume()
    {
        super.onResume();
        mSensorManager.registerListener(_SensorEventListener, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
        mSensorManager.registerListener(_SensorEventListener, mGyroscope, SensorManager.SENSOR_DELAY_NORMAL);
    }
    SensorEventListener _SensorEventListener=   new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            if (event.sensor.getType()==Sensor.TYPE_LINEAR_ACCELERATION)
            {
                if(MainActivity.state==1)
                {
                acc.ax = event.values[0];
                acc.ay = event.values[1];
                acc.az = event.values[2];
                }
                if(MainActivity.state==0)
                {
                    acc.ax = acc.ay = acc.az = 555;
                }
                if(MainActivity.state>=2)
                {
                    acc.ax = acc.ay = acc.az = 999;
                }

                Configure.main.txt.setText(event.sensor.getName() + "\n" + "X: " + event.values[0] + "\n" + "Y: " + event.values[1] + "\n" + "Z: " + event.values[2] + "\n" + "R: " + Math.sqrt(event.values[0] * event.values[0] + event.values[1] * event.values[1] + event.values[2] * event.values[2]));
                MainActivity.a = (new Float(acc.ax)).toString() + "," + (new Float(acc.ay)).toString() + "," + (new Float(acc.az)).toString();
            }
            else {
                Configure.main.txt2.setText(event.sensor.getName() + "\n" + "X: " + event.values[0] + "\n" + "Y: " + event.values[1] + "\n" + "Z: " + event.values[2] + "\n" + "R: " + Math.sqrt(event.values[0] * event.values[0] + event.values[1] * event.values[1] + event.values[2] * event.values[2]));
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };

    class ServerThread implements Runnable
    {
        boolean success=true;
        CommunicationThread temp=null;
        public void run()
        {
            Socket socket = null;
            try
            {
                serverSocket = new ServerSocket(SERVERPORT);
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
            while( (!Thread.currentThread().isInterrupted())||(status()==true))
            {

                try
                {

                    socket = serverSocket.accept();
                    socket.setSoTimeout(1000);
                    CommunicationThread commThread = new CommunicationThread(socket,this);
                    new Thread(commThread).start();
                    this.temp=commThread;

                }
                catch(SocketTimeoutException e)
                {
                    try
                    {
                        this.success = false;
                        this.wait(30);
                        socket = serverSocket.accept();
                        socket.setSoTimeout(1000);
                        CommunicationThread commThread = new CommunicationThread(socket, this);
                        new Thread(commThread).start();
                        this.temp = commThread;
                    }
                    catch (Exception exc)
                    {
                        exc.printStackTrace();
                    }

                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }

            }
        }
        boolean status()
        {
            if(temp.status()==false)
            {
                return(false);
            }
            return(this.success);
        }
    }

    class CommunicationThread implements Runnable {

        private Socket clientSocket;

        private PrintWriter output;
        boolean success=true;
        ServerThread temp=null;
        public CommunicationThread(Socket clientSocket,ServerThread a)
        {
            this.temp=a;
            this.clientSocket = clientSocket;

            try {
                this.output = new PrintWriter(new OutputStreamWriter(this.clientSocket.getOutputStream()),true);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void run()
        {

            while((!Thread.currentThread().isInterrupted())||(status()==true) )
            {

                try {

                    this.output.println(MainActivity.a);
                    this.output.flush();


                } catch (Exception e)
                {
                    e.printStackTrace();
                }

            }
        }
        boolean status()
        {
            if(temp.status()==false)
            {
                return(false);
            }
            return(this.success);
        }


    }

}
